import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import IntersectObserver from '@/components/common/IntersectObserver';
import routes from './routes';
import { CartProvider } from '@/contexts/CartContext';
import Layout from '@/components/layout/Layout';
import { Toaster } from '@/components/ui/toaster';

const App: React.FC = () => {
  return (
    <CartProvider>
      <Router>
        <IntersectObserver />
        <Layout>
          <Routes>
            {routes.map((route, index) => (
              <Route
                key={index}
                path={route.path}
                element={route.element}
              />
            ))}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Layout>
        <Toaster />
      </Router>
    </CartProvider>
  );
};

export default App;
