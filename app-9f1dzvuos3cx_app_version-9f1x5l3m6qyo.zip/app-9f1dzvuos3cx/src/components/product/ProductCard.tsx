import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Product } from '@/data/products';
import { useCart } from '@/contexts/CartContext';
import { useToast } from '@/hooks/use-toast';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  const { toast } = useToast();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: 1,
      image: product.images[0],
    });
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your shopping bag.`,
    });
  };

  const isSale = product.compareAtPrice && product.compareAtPrice > product.price;

  return (
    <Link to={`/products/${product.id}`} className="group block">
      <div className="relative aspect-[4/5] overflow-hidden bg-muted mb-4 rounded-lg">
        {/* Placeholder image logic - will be replaced with real URLs later */}
        <img
          src={product.images[0]}
          alt={product.name}
          className="object-cover w-full h-full transition-transform duration-500 group-hover:scale-110"
        />
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {isSale && (
            <Badge className="bg-destructive text-destructive-foreground hover:bg-destructive font-bold uppercase text-[10px]">
              Sale
            </Badge>
          )}
          {product.tags.includes('new') && (
            <Badge className="bg-accent text-white hover:bg-accent font-bold uppercase text-[10px]">
              New
            </Badge>
          )}
        </div>

        {/* Quick Add Overlay */}
        <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center p-4">
          <Button 
            onClick={handleAddToCart}
            className="w-full bg-white text-black hover:bg-black hover:text-white transition-colors gap-2 font-bold uppercase text-xs tracking-widest h-11"
          >
            <ShoppingBag className="h-4 w-4" />
            Quick Add
          </Button>
        </div>
      </div>

      <div className="space-y-1">
        <div className="flex justify-between items-start">
          <h3 className="text-sm font-medium text-foreground group-hover:text-accent transition-colors">
            {product.name}
          </h3>
          <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
            <Star className="h-3 w-3 fill-accent text-accent" />
            <span>{product.reviews.rating} ({product.reviews.count})</span>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold">${product.price}</span>
          {isSale && (
            <span className="text-sm text-muted-foreground line-through">${product.compareAtPrice}</span>
          )}
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;
