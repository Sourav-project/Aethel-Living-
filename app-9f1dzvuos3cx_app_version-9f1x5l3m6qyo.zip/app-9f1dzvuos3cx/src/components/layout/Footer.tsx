import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter, Youtube, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const Footer: React.FC = () => {
  return (
    <footer className="bg-secondary text-secondary-foreground border-t border-border">
      <div className="container mx-auto px-4 md:px-8 py-12 md:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand Info */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold uppercase tracking-tighter italic">
              Aethel <span className="text-accent not-italic">Living</span>
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Curating exceptional pieces for the modern home. Sustainable materials, timeless design, and unparalleled craftsmanship.
            </p>
            <div className="flex gap-4">
              <Button variant="ghost" size="icon" className="hover:text-accent">
                <Instagram className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-accent">
                <Facebook className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-accent">
                <Twitter className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-widest mb-6">Shop</h4>
            <ul className="space-y-4">
              {['All Products', 'New Arrivals', 'Best Sellers', 'Home Decor', 'Textiles'].map((link) => (
                <li key={link}>
                  <Link to={`/collections/${link.toLowerCase().replace(' ', '-')}`} className="text-sm text-muted-foreground hover:text-accent transition-colors">
                    {link}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-widest mb-6">Support</h4>
            <ul className="space-y-4">
              {['Contact Us', 'FAQ', 'Shipping Policy', 'Returns & Refunds', 'Privacy Policy'].map((link) => (
                <li key={link}>
                  <Link to={`/pages/${link.toLowerCase().replace(' ', '-')}`} className="text-sm text-muted-foreground hover:text-accent transition-colors">
                    {link}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div className="space-y-6">
            <h4 className="text-sm font-bold uppercase tracking-widest">Join our Newsletter</h4>
            <p className="text-sm text-muted-foreground">
              Sign up for exclusive offers, events and news.
            </p>
            <div className="flex gap-2">
              <Input 
                type="email" 
                placeholder="email@example.com" 
                className="bg-background border-border"
              />
              <Button size="icon" variant="default">
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-muted-foreground">
            © 2026 Aethel Living. All rights reserved.
          </p>
          <div className="flex gap-4">
            {/* Payment Icons Simulation */}
            {['Visa', 'Mastercard', 'Amex', 'PayPal', 'Apple Pay'].map((p) => (
              <span key={p} className="text-[10px] font-bold tracking-tighter border border-border px-2 py-0.5 rounded text-muted-foreground uppercase">
                {p}
              </span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
