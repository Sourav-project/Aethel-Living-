import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingBag, Search, Menu, X, ChevronRight, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { cn } from '@/lib/utils';

const Header: React.FC = () => {
  const { totalItems } = useCart();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'All Products', href: '/collections/all' },
    { name: 'Home Decor', href: '/collections/home-decor' },
    { name: 'Textiles', href: '/collections/textiles' },
    { name: 'Track Order', href: '/track-order' },
    { name: 'Contact', href: '/pages/contact-us' },
    { name: 'About', href: '/pages/about' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full">
      {/* Announcement Bar */}
      <div className="bg-primary text-primary-foreground py-2 text-center text-xs font-medium tracking-wider uppercase">
        Free shipping on orders over $150
      </div>

      {/* Main Header */}
      <div className="bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4 md:px-8 h-16 md:h-20 flex items-center justify-between">
          {/* Mobile Menu Trigger */}
          <div className="md:hidden flex-1">
            <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] sm:w-[400px]">
                <SheetHeader className="text-left border-b pb-4 mb-4">
                  <SheetTitle className="text-2xl font-bold tracking-tight">Menu</SheetTitle>
                </SheetHeader>
                <nav className="flex flex-col gap-6">
                  {navLinks.map((link) => (
                    <Link
                      key={link.href}
                      to={link.href}
                      className={cn(
                        "text-lg font-medium transition-colors hover:text-accent flex items-center justify-between group",
                        location.pathname === link.href ? "text-accent" : "text-foreground"
                      )}
                      onClick={() => setIsMenuOpen(false)}
                    >
                      {link.name}
                      <ChevronRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </Link>
                  ))}
                </nav>
              </SheetContent>
            </Sheet>
          </div>

          <div className="flex-1 md:flex-none text-center md:text-left">
            <Link to="/" className="text-xl md:text-2xl font-bold tracking-tighter uppercase italic group">
              <span className="group-hover:text-accent transition-colors">Aethel</span> <span className="text-accent not-italic group-hover:text-foreground transition-colors">Living</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8 flex-1 justify-center">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className={cn(
                  "text-sm font-medium tracking-wide uppercase transition-colors hover:text-accent relative py-1",
                  location.pathname === link.href 
                    ? "text-accent after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-accent" 
                    : "text-foreground"
                )}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex-1 md:flex-none flex items-center justify-end gap-1 md:gap-4">
            <Button variant="ghost" size="icon" className="hidden sm:inline-flex">
              <Search className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="hidden sm:inline-flex">
              <User className="h-5 w-5" />
            </Button>
            <Link to="/cart">
              <Button variant="ghost" size="icon" className="relative group">
                <ShoppingBag className="h-5 w-5 group-hover:scale-110 transition-transform" />
                {totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 bg-accent text-white text-[10px] font-bold h-4 w-4 rounded-full flex items-center justify-center animate-fade-in">
                    {totalItems}
                  </span>
                )}
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
