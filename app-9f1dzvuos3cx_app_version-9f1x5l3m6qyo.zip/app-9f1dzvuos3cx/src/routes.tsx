import Home from './pages/Home';
import Collections from './pages/Collections';
import ProductDetail from './pages/ProductDetail';
import Cart from './pages/Cart';
import StaticPage from './pages/StaticPage';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <Home />
  },
  {
    name: 'Collections',
    path: '/collections/:category',
    element: <Collections />
  },
  {
    name: 'Product Detail',
    path: '/products/:id',
    element: <ProductDetail />
  },
  {
    name: 'Cart',
    path: '/cart',
    element: <Cart />
  },
  {
    name: 'Static Pages',
    path: '/pages/:slug',
    element: <StaticPage />
  }
];

export default routes;
