import React from 'react';
import { useParams } from 'react-router-dom';
import { Mail, Phone, MapPin, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const StaticPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();

  const getContent = () => {
    switch (slug) {
      case 'about':
        return (
          <div className="space-y-12">
            <div className="space-y-6">
              <h1 className="text-4xl md:text-6xl font-bold tracking-tighter uppercase italic">Our <span className="not-italic">Story</span></h1>
              <p className="text-xl text-muted-foreground leading-relaxed max-w-3xl">
                Founded in 2026, Aethel Living was born out of a desire for more intentional living. We believe that your home should be a reflection of your values—a sanctuary filled with objects that inspire and endure.
              </p>
            </div>
            <div className="aspect-[21/9] bg-muted rounded-2xl overflow-hidden">
              <img src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_e2becb32-e23b-45e5-831c-572d7608d82c.jpg" alt="Our workshop" className="w-full h-full object-cover" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
              <div className="space-y-4">
                <h3 className="text-2xl font-bold uppercase tracking-tight italic">Our Mission</h3>
                <p className="text-muted-foreground leading-relaxed">
                  To provide a curated platform for artisans and designers who prioritize quality, ethics, and sustainability. We aim to bridge the gap between traditional craftsmanship and modern living.
                </p>
              </div>
              <div className="space-y-4">
                <h3 className="text-2xl font-bold uppercase tracking-tight italic">Our Promise</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Every item in our store is hand-selected. We vet our partners for fair labor practices and environmental responsibility, ensuring that your purchase supports a better world.
                </p>
              </div>
            </div>
          </div>
        );
      case 'contact-us':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
            <div className="space-y-12">
              <div className="space-y-6">
                <h1 className="text-4xl md:text-6xl font-bold tracking-tighter uppercase italic">Contact <span className="not-italic">Us</span></h1>
                <p className="text-muted-foreground leading-relaxed">
                  Have a question about an order, a product, or just want to say hello? Our team is here to help. Reach out through any of the channels below or use the contact form.
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div className="flex gap-4">
                  <Mail className="h-6 w-6 text-accent shrink-0" />
                  <div>
                    <p className="font-bold uppercase tracking-widest text-xs mb-1">Email</p>
                    <p className="text-sm text-muted-foreground">hello@aethel-living.com</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <Phone className="h-6 w-6 text-accent shrink-0" />
                  <div>
                    <p className="font-bold uppercase tracking-widest text-xs mb-1">Phone</p>
                    <p className="text-sm text-muted-foreground">+1 (800) 123-4567</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <MapPin className="h-6 w-6 text-accent shrink-0" />
                  <div>
                    <p className="font-bold uppercase tracking-widest text-xs mb-1">Address</p>
                    <p className="text-sm text-muted-foreground">123 Design District, NY 10001</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <MessageSquare className="h-6 w-6 text-accent shrink-0" />
                  <div>
                    <p className="font-bold uppercase tracking-widest text-xs mb-1">Live Chat</p>
                    <p className="text-sm text-muted-foreground">Available Mon-Fri, 9am-5pm EST</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-secondary/30 p-10 rounded-2xl border border-border">
              <form className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-[0.2em]">First Name</label>
                    <Input placeholder="Jane" className="bg-background rounded-none" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-[0.2em]">Last Name</label>
                    <Input placeholder="Doe" className="bg-background rounded-none" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-[0.2em]">Email Address</label>
                  <Input type="email" placeholder="jane@example.com" className="bg-background rounded-none" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-[0.2em]">Message</label>
                  <Textarea placeholder="How can we help?" className="bg-background rounded-none min-h-[150px]" />
                </div>
                <Button className="w-full h-14 rounded-none uppercase tracking-widest text-xs font-bold">Send Message</Button>
              </form>
            </div>
          </div>
        );
      case 'faq':
        return (
          <div className="max-w-3xl mx-auto space-y-12">
            <div className="text-center space-y-4">
              <h1 className="text-4xl md:text-6xl font-bold tracking-tighter uppercase italic">Frequently <br /><span className="not-italic">Asked Questions</span></h1>
              <p className="text-muted-foreground">Everything you need to know about our products and services.</p>
            </div>
            <Accordion type="single" collapsible className="w-full">
              {[
                { q: "What is your shipping policy?", a: "We offer free standard shipping on orders over $150. For smaller orders, a flat rate of $9 applies. Express shipping is available for $25." },
                { q: "Do you ship internationally?", a: "Yes, we ship to over 50 countries. International shipping rates and delivery times vary by location." },
                { q: "How do I care for my ceramic pieces?", a: "Our ceramics are generally dishwasher safe, but we recommend hand washing with mild soap to preserve the finish over time." },
                { q: "What is your return policy?", a: "You can return items in original condition within 30 days of delivery. Return shipping is free for domestic orders." },
                { q: "Are your products eco-friendly?", a: "Sustainability is at our core. We use GOTS certified organic cotton, recycled packaging, and partner with ethically audited workshops." },
              ].map((item, i) => (
                <AccordionItem key={i} value={`item-${i}`} className="border-border px-4 hover:bg-secondary/20 transition-colors">
                  <AccordionTrigger className="text-sm font-bold uppercase tracking-widest py-6 hover:no-underline">{item.q}</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed pb-6">{item.a}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        );
      default:
        return (
          <div className="max-w-3xl mx-auto space-y-8">
            <h1 className="text-4xl font-bold tracking-tighter uppercase italic">{slug?.replace('-', ' ')}</h1>
            <div className="prose prose-sm max-w-none text-muted-foreground leading-relaxed space-y-6">
              <p>This is a simulated policy page. In a real store, this would contain legal text regarding your store's operation.</p>
              <h3 className="text-foreground font-bold uppercase text-xs tracking-widest">Section 1: Introduction</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              <h3 className="text-foreground font-bold uppercase text-xs tracking-widest">Section 2: Terms of Use</h3>
              <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="container mx-auto px-4 md:px-8 py-20 min-h-[60vh]">
      {getContent()}
    </div>
  );
};

export default StaticPage;
