import React, { useState, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Filter, SlidersHorizontal, ChevronDown, LayoutGrid, LayoutList } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';
import { products, collections as collectionData } from '@/data/products';
import ProductCard from '@/components/product/ProductCard';
import { cn } from '@/lib/utils';


const Collections: React.FC = () => {
  const { category } = useParams<{ category: string }>();
  const [sortBy, setSortBy] = useState('featured');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const activeCollection = category === 'all' 
    ? { name: 'All Products', description: 'Explore our entire range of artisan-crafted pieces.', image: 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_8d83f5f1-c833-4940-a9c9-c621bf21810c.jpg' }
    : collectionData.find(c => c.id === category) || { name: 'Collection', description: '', image: 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_58efe1d1-b993-4837-88d4-444ea80cedc1.jpg' };

  const filteredProducts = useMemo(() => {
    let result = category === 'all' 
      ? products 
      : products.filter(p => p.category.toLowerCase().replace(' ', '-') === category);

    switch (sortBy) {
      case 'price-low':
        result = [...result].sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        result = [...result].sort((a, b) => b.price - a.price);
        break;
      case 'newest':
        result = [...result].reverse(); // Simulation
        break;
      default:
        break;
    }
    return result;
  }, [category, sortBy]);

  const sortLabels: Record<string, string> = {
    featured: 'Featured',
    'price-low': 'Price: Low to High',
    'price-high': 'Price: High to Low',
    newest: 'Newest Arrivals',
  };

  return (
    <div className="pb-20">
      {/* Collection Hero */}
      <section className="relative h-[40vh] min-h-[300px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={activeCollection.image} 
            alt={activeCollection.name} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/40" />
        </div>
        <div className="container mx-auto px-4 relative z-10 text-center text-white">
          <h1 className="text-4xl md:text-7xl font-bold tracking-tighter uppercase italic mb-4">{activeCollection.name}</h1>
          <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto leading-relaxed">
            {activeCollection.description}
          </p>
        </div>
      </section>

      {/* Toolbar */}
      <section className="sticky top-16 md:top-20 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="container mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <Button variant="ghost" className="gap-2 text-xs font-bold uppercase tracking-widest p-0 md:p-2">
              <SlidersHorizontal className="h-4 w-4" />
              <span className="hidden md:inline">Filter</span>
            </Button>
            <Separator orientation="vertical" className="h-4 hidden md:block" />
            <span className="text-xs text-muted-foreground font-medium hidden md:inline">
              Showing {filteredProducts.length} Products
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 border border-border rounded-md p-1">
              <Button 
                variant={viewMode === 'grid' ? 'secondary' : 'ghost'} 
                size="icon" 
                className="h-8 w-8"
                onClick={() => setViewMode('grid')}
              >
                <LayoutGrid className="h-4 w-4" />
              </Button>
              <Button 
                variant={viewMode === 'list' ? 'secondary' : 'ghost'} 
                size="icon" 
                className="h-8 w-8"
                onClick={() => setViewMode('list')}
              >
                <LayoutList className="h-4 w-4" />
              </Button>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2 text-xs font-bold uppercase tracking-widest border-border min-w-[160px] justify-between">
                  Sort: {sortLabels[sortBy]}
                  <ChevronDown className="h-4 w-4 opacity-50" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground">Sort By</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {Object.entries(sortLabels).map(([key, label]) => (
                  <DropdownMenuItem 
                    key={key} 
                    className="text-sm font-medium py-2 px-3 focus:bg-accent focus:text-white"
                    onClick={() => setSortBy(key)}
                  >
                    {label}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 md:px-8 pt-12">
        {filteredProducts.length > 0 ? (
          <div className={cn(
            "grid gap-6 md:gap-10",
            viewMode === 'grid' 
              ? "grid-cols-2 lg:grid-cols-4" 
              : "grid-cols-1"
          )}>
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="py-32 text-center space-y-4">
            <h3 className="text-xl font-bold uppercase tracking-tighter italic">No products found</h3>
            <p className="text-muted-foreground">Try adjusting your filters or category.</p>
            <Button asChild variant="outline">
              <Link to="/collections/all">View All Products</Link>
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Collections;
