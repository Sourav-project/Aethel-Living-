import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Truck, RotateCcw, ShieldCheck, CreditCard, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { products, collections } from '@/data/products';
import ProductCard from '@/components/product/ProductCard';

const Home: React.FC = () => {
  const featuredProducts = products.slice(0, 4);

  return (
    <div className="space-y-20 md:space-y-32 mb-20">
      {/* Hero Section */}
      <section className="relative h-[80vh] min-h-[600px] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_be17e7fc-8270-4f0f-9480-c4becb55e73a.jpg" 
            alt="Minimalist modern living room with artisan decor" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/20" />
        </div>
        
        <div className="container mx-auto px-4 md:px-8 relative z-10 text-white">
          <div className="max-w-2xl space-y-6 md:space-y-8 animate-fade-in">
            <h4 className="text-sm md:text-base font-bold uppercase tracking-[0.3em]">Spring Collection 2026</h4>
            <h1 className="text-5xl md:text-8xl font-bold tracking-tighter leading-tight italic">
              Timeless <br /> <span className="not-italic text-accent">Simplicity.</span>
            </h1>
            <p className="text-lg md:text-xl text-white/90 max-w-lg leading-relaxed">
              Discover our curated selection of hand-crafted pieces designed to elevate your everyday living. Sustainable materials meets modern aesthetics.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button asChild size="lg" className="h-14 px-10 rounded-none uppercase tracking-widest text-xs font-bold bg-white text-black hover:bg-black hover:text-white transition-all border-none shadow-xl">
                <Link to="/collections/all">Shop Collection</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="h-14 px-10 rounded-none uppercase tracking-widest text-xs font-bold border-white text-white hover:bg-white hover:text-black transition-all bg-black/20 backdrop-blur-sm">
                <Link to="/pages/about">Our Story</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Signals / Benefits */}
      <section className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12 border-y border-border py-12">
          {[
            { icon: Truck, title: 'Free Shipping', desc: 'On orders over $150' },
            { icon: RotateCcw, title: '30-Day Returns', desc: 'Hassle-free exchange' },
            { icon: ShieldCheck, title: 'Secure Payment', desc: '100% encrypted checkout' },
            { icon: CreditCard, title: 'Buy Now, Pay Later', desc: 'Interest-free installments' },
          ].map((benefit, idx) => (
            <div key={idx} className="flex flex-col items-center text-center space-y-3">
              <benefit.icon className="h-6 w-6 text-accent" />
              <h3 className="text-xs font-bold uppercase tracking-widest">{benefit.title}</h3>
              <p className="text-xs text-muted-foreground">{benefit.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Collections */}
      <section className="container mx-auto px-4 md:px-8">
        <div className="flex justify-between items-end mb-12">
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-widest text-accent">Curated For You</h4>
            <h2 className="text-3xl md:text-5xl font-bold tracking-tighter uppercase italic">Shop <span className="not-italic">By Category</span></h2>
          </div>
          <Button variant="link" asChild className="uppercase tracking-widest text-xs font-bold gap-2">
            <Link to="/collections/all">View All Collections <ArrowRight className="h-4 w-4" /></Link>
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {collections.map((collection) => (
            <Link 
              key={collection.id} 
              to={`/collections/${collection.id}`}
              className="group relative aspect-[4/5] overflow-hidden rounded-lg bg-muted"
            >
              <img 
                src={collection.image} 
                alt={collection.name} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-colors" />
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-6">
                <h3 className="text-2xl font-bold tracking-tighter uppercase mb-2">{collection.name}</h3>
                <p className="text-xs font-medium tracking-widest uppercase opacity-0 group-hover:opacity-100 transition-opacity translate-y-4 group-hover:translate-y-0 duration-300">
                  Shop Now
                </p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="bg-secondary/50 py-24 md:py-32">
        <div className="container mx-auto px-4 md:px-8">
          <div className="text-center space-y-4 mb-16">
            <h4 className="text-xs font-bold uppercase tracking-widest text-accent">Selected Items</h4>
            <h2 className="text-3xl md:text-5xl font-bold tracking-tighter uppercase italic">Best <span className="not-italic">Sellers</span></h2>
            <div className="h-1 w-20 bg-accent mx-auto" />
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 md:gap-10">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <div className="mt-16 text-center">
            <Button asChild size="lg" variant="outline" className="h-14 px-12 uppercase tracking-widest text-xs font-bold border-primary hover:bg-primary hover:text-white transition-all">
              <Link to="/collections/all">View All Products</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Brand Ethos / Mission */}
      <section className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="relative aspect-[4/3] rounded-lg overflow-hidden">
            <img 
              src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_79fe4c6e-63a1-4cb8-9d17-39c678fb5fb9.jpg" 
              alt="Artisan at work crafting ceramic pieces" 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="space-y-8">
            <h4 className="text-xs font-bold uppercase tracking-widest text-accent">Our Ethos</h4>
            <h2 className="text-4xl md:text-6xl font-bold tracking-tighter leading-tight italic">Made for <span className="not-italic">the intentional home.</span></h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              We believe that the objects we surround ourselves with should tell a story. That's why we partner with independent artisans who share our commitment to quality, sustainability, and thoughtful design.
            </p>
            <div className="space-y-4">
              {[
                'Ethically sourced materials from sustainable origins',
                'Hand-crafted by master artisans across the globe',
                'Timeless designs meant to last a lifetime',
              ].map((point, i) => (
                <div key={i} className="flex items-center gap-4">
                  <div className="h-2 w-2 rounded-full bg-accent" />
                  <span className="text-sm font-medium tracking-wide">{point}</span>
                </div>
              ))}
            </div>
            <Button asChild size="lg" className="h-14 px-10 rounded-none uppercase tracking-widest text-xs font-bold">
              <Link to="/pages/about">Read Our Story</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-primary text-primary-foreground py-24 md:py-32 overflow-hidden">
        <div className="container mx-auto px-4 md:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col items-center text-center space-y-12">
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-accent text-accent" />
                ))}
              </div>
              <blockquote className="text-2xl md:text-4xl font-medium italic leading-relaxed tracking-tight">
                "The attention to detail in these pieces is extraordinary. Every item I've purchased from Aethel Living has become a conversation starter in my home. Truly exceptional craftsmanship."
              </blockquote>
              <div className="space-y-1">
                <p className="font-bold uppercase tracking-[0.2em] text-sm">Eleanor Vance</p>
                <p className="text-xs text-primary-foreground/60 uppercase tracking-widest">Architect & Interior Designer</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Instagram Grid Simulation */}
      <section className="container mx-auto px-4 md:px-8">
        <div className="text-center space-y-4 mb-12">
          <h4 className="text-xs font-bold uppercase tracking-widest text-accent">Social Community</h4>
          <h2 className="text-3xl md:text-4xl font-bold tracking-tighter uppercase italic">Follow <span className="not-italic">Our Journey</span></h2>
          <p className="text-sm text-muted-foreground italic">@aethel_living_official</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {[
            "https://miaoda-site-img.s3cdn.medo.dev/images/KLing_b611529d-4f3b-4862-9e38-75671059a67f.jpg",
            "https://miaoda-site-img.s3cdn.medo.dev/images/KLing_432c9b63-8d78-46c1-aa35-875e87802578.jpg",
            "https://miaoda-site-img.s3cdn.medo.dev/images/KLing_55113028-4ae5-4bd1-8b7f-f0a92b018991.jpg",
            "https://miaoda-site-img.s3cdn.medo.dev/images/KLing_58efe1d1-b993-4837-88d4-444ea80cedc1.jpg",
            "https://miaoda-site-img.s3cdn.medo.dev/images/KLing_58bb4475-76e3-465e-89ab-579db18e0764.jpg",
            "https://miaoda-site-img.s3cdn.medo.dev/images/KLing_8d83f5f1-c833-4940-a9c9-c621bf21810c.jpg"
          ].map((url, i) => (
            <div key={i} className="aspect-square bg-muted rounded overflow-hidden relative group cursor-pointer">
              <img src={url} alt={`Social post ${i}`} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
              <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="text-white text-xs font-bold uppercase tracking-widest">View Post</span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;
