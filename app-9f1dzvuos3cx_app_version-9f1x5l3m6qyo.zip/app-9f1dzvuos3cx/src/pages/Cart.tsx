import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Trash2, Plus, Minus, ArrowRight, Truck, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { useCart } from '@/contexts/CartContext';

const Cart: React.FC = () => {
  const { cart, updateQuantity, removeFromCart, totalPrice, totalItems } = useCart();

  if (cart.length === 0) {
    return (
      <div className="container mx-auto px-4 py-32 text-center">
        <div className="flex flex-col items-center space-y-6 max-w-md mx-auto">
          <div className="h-24 w-24 bg-muted rounded-full flex items-center justify-center">
            <ShoppingBag className="h-10 w-10 text-muted-foreground" />
          </div>
          <h1 className="text-3xl font-bold tracking-tighter uppercase italic">Your bag is empty</h1>
          <p className="text-muted-foreground leading-relaxed">
            Looks like you haven't added any items to your bag yet. Start exploring our collections and find something you love.
          </p>
          <Button asChild size="lg" className="h-14 px-10 rounded-none uppercase tracking-widest text-xs font-bold w-full">
            <Link to="/collections/all">Start Shopping</Link>
          </Button>
        </div>
      </div>
    );
  }

  const shippingThreshold = 150;
  const shippingProgress = Math.min(100, (totalPrice / shippingThreshold) * 100);
  const remainingForFreeShipping = Math.max(0, shippingThreshold - totalPrice);

  return (
    <div className="container mx-auto px-4 md:px-8 py-12 md:py-20">
      <h1 className="text-4xl md:text-5xl font-bold tracking-tighter uppercase italic mb-12">Shopping <span className="not-italic">Bag</span></h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-8">
          {/* Free Shipping Progress */}
          <div className="bg-secondary/50 p-6 rounded-xl space-y-4 border border-border">
            <div className="flex justify-between items-center text-xs font-bold uppercase tracking-widest">
              <span>{remainingForFreeShipping > 0 
                ? `You're $${remainingForFreeShipping.toFixed(2)} away from free shipping` 
                : "You've unlocked free shipping!"}</span>
              <span>${totalPrice.toFixed(2)} / ${shippingThreshold}</span>
            </div>
            <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
              <div 
                className="h-full bg-accent transition-all duration-1000" 
                style={{ width: `${shippingProgress}%` }} 
              />
            </div>
          </div>

          <div className="space-y-6">
            {cart.map((item) => (
              <div key={item.id} className="flex gap-6 py-6 border-b border-border last:border-0 group">
                <Link to={`/products/${item.id}`} className="shrink-0 aspect-[3/4] w-24 md:w-32 bg-muted rounded-lg overflow-hidden">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                </Link>
                <div className="flex-1 flex flex-col justify-between">
                  <div className="flex justify-between items-start">
                    <div>
                      <Link to={`/products/${item.id}`} className="text-lg font-bold uppercase tracking-tight hover:text-accent transition-colors">
                        {item.name}
                      </Link>
                      {item.variant && <p className="text-xs text-muted-foreground uppercase tracking-widest mt-1">{item.variant}</p>}
                    </div>
                    <p className="font-bold text-lg">${(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                  
                  <div className="flex justify-between items-end mt-4">
                    <div className="flex items-center border border-border rounded-lg p-1 bg-background">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8"
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <span className="w-10 text-center text-sm font-bold">{item.quantity}</span>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8"
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-muted-foreground hover:text-destructive transition-colors h-8 w-8"
                      onClick={() => removeFromCart(item.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-secondary/30 p-8 rounded-2xl border border-border sticky top-32">
            <h2 className="text-xl font-bold uppercase tracking-tighter mb-6">Order Summary</h2>
            
            <div className="space-y-4">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal ({totalItems} items)</span>
                <span className="font-bold">${totalPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Estimated Shipping</span>
                <span className="font-bold">{totalPrice >= shippingThreshold ? 'FREE' : '$15.00'}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Estimated Tax</span>
                <span className="font-bold">${(totalPrice * 0.08).toFixed(2)}</span>
              </div>
              <Separator className="bg-border/50" />
              <div className="flex justify-between items-end pt-2">
                <span className="text-lg font-bold uppercase tracking-tighter italic">Total</span>
                <div className="text-right">
                  <p className="text-2xl font-bold tracking-tight">
                    ${(totalPrice + (totalPrice >= shippingThreshold ? 0 : 15) + (totalPrice * 0.08)).toFixed(2)}
                  </p>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-widest">or 4 payments of ${(totalPrice / 4).toFixed(2)}</p>
                </div>
              </div>
            </div>

            <div className="mt-8 space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground">Promo Code</label>
                <div className="flex gap-2">
                  <Input placeholder="Enter code" className="bg-background rounded-none h-11" />
                  <Button variant="outline" className="rounded-none h-11 px-6 uppercase tracking-widest text-[10px] font-bold">Apply</Button>
                </div>
              </div>
              
              <Button className="w-full h-14 rounded-none uppercase tracking-widest text-xs font-bold bg-primary hover:bg-accent transition-all duration-300 gap-3">
                Checkout Now
                <ArrowRight className="h-4 w-4" />
              </Button>
              
              <div className="flex flex-col gap-3 pt-6 border-t border-border mt-6">
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <ShieldCheck className="h-4 w-4 text-accent" />
                  <span>Secure SSL Encrypted Checkout</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <Truck className="h-4 w-4 text-accent" />
                  <span>Tracked Carbon Neutral Delivery</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
