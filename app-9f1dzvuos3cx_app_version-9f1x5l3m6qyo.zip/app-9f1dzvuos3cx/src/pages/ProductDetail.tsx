import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ShoppingBag, Heart, Share2, Star, Truck, Shield, RotateCcw, ChevronLeft, ChevronRight, Plus, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { products } from '@/data/products';
import { useCart } from '@/contexts/CartContext';
import { useToast } from '@/hooks/use-toast';
import ProductCard from '@/components/product/ProductCard';
import { cn } from '@/lib/utils';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const product = products.find((p) => p.id === id);
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
        <Button asChild>
          <Link to="/collections/all">Return to Shop</Link>
        </Button>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: quantity,
      image: product.images[0],
    });
    toast({
      title: "Added to cart",
      description: `${quantity} x ${product.name} added to your bag.`,
    });
  };

  const relatedProducts = products.filter((p) => p.id !== product.id && p.category === product.category).slice(0, 4);
  const isSale = product.compareAtPrice && product.compareAtPrice > product.price;

  return (
    <div className="pb-20">
      {/* Breadcrumbs */}
      <div className="bg-secondary/30 py-4">
        <div className="container mx-auto px-4 md:px-8">
          <nav className="flex items-center text-xs font-medium uppercase tracking-widest text-muted-foreground">
            <Link to="/" className="hover:text-accent">Home</Link>
            <span className="mx-2">/</span>
            <Link to={`/collections/${product.category.toLowerCase().replace(' ', '-')}`} className="hover:text-accent">{product.category}</Link>
            <span className="mx-2">/</span>
            <span className="text-foreground">{product.name}</span>
          </nav>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-8 pt-8 md:pt-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Image Gallery */}
          <div className="space-y-4">
            <div className="relative aspect-[4/5] overflow-hidden bg-muted rounded-xl">
              <img 
                src={product.images[activeImage]} 
                alt={product.name} 
                className="w-full h-full object-cover transition-all duration-500"
              />
              {isSale && (
                <Badge className="absolute top-6 left-6 bg-destructive text-destructive-foreground px-4 py-1.5 font-bold uppercase tracking-widest text-xs">
                  Save ${(product.compareAtPrice || 0) - product.price}
                </Badge>
              )}
            </div>
            {product.images.length > 1 && (
              <div className="grid grid-cols-4 gap-4">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImage(idx)}
                    className={cn(
                      "aspect-square rounded-md overflow-hidden border-2 transition-all",
                      activeImage === idx ? "border-accent" : "border-transparent opacity-60 hover:opacity-100"
                    )}
                  >
                    <img src={img} alt={`${product.name} ${idx + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="flex flex-col">
            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-2 text-accent font-bold uppercase tracking-widest text-xs">
                <span>{product.category}</span>
                <span className="h-1 w-1 rounded-full bg-accent" />
                <span>SKU: {product.sku}</span>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold tracking-tighter uppercase italic">{product.name}</h1>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      className={cn(
                        "h-4 w-4", 
                        i < Math.floor(product.reviews.rating) ? "fill-accent text-accent" : "text-muted"
                      )} 
                    />
                  ))}
                  <span className="text-sm font-bold ml-2">{product.reviews.rating}</span>
                </div>
                <Separator orientation="vertical" className="h-4" />
                <span className="text-sm text-muted-foreground">{product.reviews.count} Reviews</span>
              </div>
              <div className="flex items-end gap-3 mt-4">
                <span className="text-3xl font-bold">${product.price}</span>
                {isSale && (
                  <span className="text-xl text-muted-foreground line-through mb-1">${product.compareAtPrice}</span>
                )}
              </div>
            </div>

            <p className="text-muted-foreground leading-relaxed mb-8">
              {product.description}
            </p>

            <div className="space-y-6 mb-10">
              <div className="space-y-3">
                <label className="text-xs font-bold uppercase tracking-widest">Quantity</label>
                <div className="flex items-center w-32 border border-border rounded-lg p-1">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  >
                    <Minus className="h-3 w-3" />
                  </Button>
                  <span className="flex-1 text-center text-sm font-bold">{quantity}</span>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8"
                    onClick={() => setQuantity(quantity + 1)}
                  >
                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  onClick={handleAddToCart}
                  className="flex-1 h-14 uppercase tracking-widest text-xs font-bold gap-3 rounded-none bg-primary hover:bg-accent transition-all duration-300"
                >
                  <ShoppingBag className="h-5 w-5" />
                  Add to Cart
                </Button>
                <Button variant="outline" className="h-14 w-14 p-0 rounded-none border-border hover:border-accent hover:text-accent transition-all">
                  <Heart className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Value Props */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-6 bg-secondary/50 border border-border rounded-xl mb-8">
              {[
                { icon: Truck, text: 'Free delivery over $150' },
                { icon: Shield, text: '2-year warranty' },
                { icon: RotateCcw, text: '30-day returns' },
              ].map((item, i) => (
                <div key={i} className="flex flex-col items-center text-center gap-2">
                  <item.icon className="h-5 w-5 text-accent" />
                  <span className="text-[10px] font-bold uppercase tracking-widest leading-tight">{item.text}</span>
                </div>
              ))}
            </div>

            <Tabs defaultValue="details" className="w-full">
              <TabsList className="w-full justify-start rounded-none border-b bg-transparent h-12 p-0 gap-8">
                <TabsTrigger value="details" className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent data-[state=active]:bg-transparent uppercase tracking-widest text-xs font-bold px-0 h-12">Details</TabsTrigger>
                <TabsTrigger value="shipping" className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent data-[state=active]:bg-transparent uppercase tracking-widest text-xs font-bold px-0 h-12">Shipping</TabsTrigger>
                <TabsTrigger value="returns" className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent data-[state=active]:bg-transparent uppercase tracking-widest text-xs font-bold px-0 h-12">Returns</TabsTrigger>
              </TabsList>
              <TabsContent value="details" className="pt-6 space-y-4">
                <ul className="space-y-3">
                  {product.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-3 text-sm text-muted-foreground">
                      <div className="h-1.5 w-1.5 rounded-full bg-accent shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </TabsContent>
              <TabsContent value="shipping" className="pt-6 text-sm text-muted-foreground leading-relaxed">
                Standard delivery (3-5 business days): $9.00 or Free on orders over $150.
                Express delivery (1-2 business days): $25.00.
                Orders are processed Monday through Friday, excluding holidays.
              </TabsContent>
              <TabsContent value="returns" className="pt-6 text-sm text-muted-foreground leading-relaxed">
                You can return your order for any reason within 30 days of delivery.
                Items must be in original condition with all tags attached.
                Return shipping is complimentary for domestic orders.
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-32">
            <div className="flex justify-between items-end mb-12">
              <h2 className="text-3xl md:text-4xl font-bold tracking-tighter uppercase italic">You May <span className="not-italic">Also Like</span></h2>
              <Button variant="link" asChild className="uppercase tracking-widest text-xs font-bold">
                <Link to="/collections/all">View All Products</Link>
              </Button>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 md:gap-10">
              {relatedProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;
