export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  compareAtPrice?: number;
  images: string[];
  category: string;
  tags: string[];
  sku: string;
  inventory: number;
  features: string[];
  reviews: {
    rating: number;
    count: number;
  };
}

export const products: Product[] = [
  {
    id: '1',
    name: 'Artisan Ceramic Vase',
    description: 'Hand-crafted ceramic vase with a textured matte finish. Perfect for minimalist home decor and floral arrangements.',
    price: 85,
    compareAtPrice: 110,
    images: ['https://miaoda-site-img.s3cdn.medo.dev/images/KLing_d26b4bb3-8b4c-497f-8221-e3fc1233c441.jpg', 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_8d83f5f1-c833-4940-a9c9-c621bf21810c.jpg'],
    category: 'Home Decor',
    tags: ['new', 'best-seller', 'handmade'],
    sku: 'HOM-VAS-001',
    inventory: 24,
    features: ['Hand-crafted', 'Eco-friendly material', 'Textured finish'],
    reviews: { rating: 4.8, count: 124 }
  },
  {
    id: '2',
    name: 'Minimalist Wall Clock',
    description: 'Silent movement wall clock with a clean Scandinavian design. Features premium oak wood and brushed metal hands.',
    price: 65,
    images: ['https://miaoda-site-img.s3cdn.medo.dev/images/KLing_7d5a825c-bc0a-4654-9428-1d36c45c8402.jpg'],
    category: 'Home Decor',
    tags: ['essential'],
    sku: 'HOM-CLK-002',
    inventory: 15,
    features: ['Silent movement', 'Premium oak wood', 'Easy installation'],
    reviews: { rating: 4.5, count: 89 }
  },
  {
    id: '3',
    name: 'Organic Cotton Throw',
    description: 'Ultra-soft throw blanket made from 100% GOTS certified organic cotton. Reversible pattern for versatile styling.',
    price: 120,
    compareAtPrice: 150,
    images: ['https://miaoda-site-img.s3cdn.medo.dev/images/KLing_4176804b-324d-4cb6-a31c-b26aa193e3ce.jpg'],
    category: 'Textiles',
    tags: ['sale', 'organic'],
    sku: 'TEX-THR-003',
    inventory: 42,
    features: ['100% Organic Cotton', 'Machine washable', 'Hypoallergenic'],
    reviews: { rating: 4.9, count: 56 }
  },
  {
    id: '4',
    name: 'Soy Wax Scented Candle',
    description: 'Hand-poured soy wax candle with essential oils of sandalwood and bergamot. 60-hour burn time.',
    price: 32,
    images: ['https://miaoda-site-img.s3cdn.medo.dev/images/KLing_d66c5557-b7a2-4e7d-b6c0-49c4a248c9bc.jpg'],
    category: 'Home Fragrance',
    tags: ['gift-idea'],
    sku: 'FRG-CAN-004',
    inventory: 100,
    features: ['Natural soy wax', 'Essential oils', 'Lead-free wick'],
    reviews: { rating: 4.7, count: 215 }
  },
  {
    id: '5',
    name: 'Modern Table Lamp',
    description: 'Sleek table lamp with a dimmable LED bulb and a matte charcoal finish. Ideal for office or bedside.',
    price: 145,
    images: ['https://miaoda-site-img.s3cdn.medo.dev/images/KLing_7beeaf85-ceaf-41aa-a28f-95190c689c5d.jpg'],
    category: 'Lighting',
    tags: ['modern', 'office'],
    sku: 'LGT-LMP-005',
    inventory: 12,
    features: ['Dimmable LED', 'Matte finish', 'Adjustable neck'],
    reviews: { rating: 4.6, count: 43 }
  },
  {
    id: '6',
    name: 'Geometric Wool Rug',
    description: 'Hand-tufted wool rug with a subtle geometric pattern. Durable and soft underfoot.',
    price: 450,
    compareAtPrice: 599,
    images: ['https://miaoda-site-img.s3cdn.medo.dev/images/KLing_1b6d783e-0709-49c6-84be-ee3a52e12fd0.jpg'],
    category: 'Textiles',
    tags: ['premium', 'sale'],
    sku: 'TEX-RUG-006',
    inventory: 8,
    features: ['100% Wool', 'Hand-tufted', 'Non-slip backing'],
    reviews: { rating: 4.8, count: 28 }
  }
];

export const collections = [
  { id: 'new-arrivals', name: 'New Arrivals', description: 'Check out our latest products', image: 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_58efe1d1-b993-4837-88d4-444ea80cedc1.jpg' },
  { id: 'best-sellers', name: 'Best Sellers', description: 'Our most popular pieces', image: 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_b611529d-4f3b-4862-9e38-75671059a67f.jpg' },
  { id: 'home-decor', name: 'Home Decor', description: 'Elevate your living space', image: 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_8d83f5f1-c833-4940-a9c9-c621bf21810c.jpg' },
  { id: 'textiles', name: 'Textiles', description: 'Cozy and sustainable fabrics', image: 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_58bb4475-76e3-465e-89ab-579db18e0764.jpg' }
];
